const fs = require('fs')

var logs = "";

module.exports ={
    log : function(str){
        addToLogFile(str)
        console.log(str)
    }
}

function addToLogFile(str){
    logs += str + '\r\n'
    fs.writeFile("log.txt",logs,function(err){
        if(err) throw err
    })
}