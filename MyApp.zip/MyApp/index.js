const _= require('./utils')
const request = require('request')
const jssoup = require('jssoup').default
const json2csv = require('json2csv').Parser
const fs = require('fs')


var fields = ['flight_date','origin','destination','price']
var fileData = []

var r = request.defaults({'proxy' : 'http://proxy.dlsu.edu.ph:80'})

function getHTMLData(callback){
    r("https://beta.cebupacificair.com/Flight/Select?o1=MNL&d1=NRT&o2=&d2=&dd1=2019-02-14&dd2=2019-02-16&r=true&ADT=1&CHD=0&INF=0&inl=0&pos=cebu.ph&culture=&p=",function(err,
        res,body){
            if(err){
                _.log(err)
                throw err
            }
            callback(body)
        })
}

function parseHTML(data){
    var soup = new jssoup(data)
     var tables = soup.nextElement.nextElement.findAll('table')
     
     for(i in tables){
         if(tables[i].attrs.id == "depart-table"){
             var farerows = tables[i].findAll('tr','faretable-row')
             for(j in farerows){
               var price = farerows[j].find('label').text.trim()  
                 
                 flightPrice = {
                     flight_date : "2019-20-14",
                     origin : 'MNL',
                     destination : 'NRT',
                     price : price
                 }
                 
                 fileData.push(flightPrice)
             }
         }
     }
    const csv = new json2csv({fields}).parse(fileData)
    fs.writeFile("cebupac.csv",csv,function(err){
        if(err) throw err
        console.log("File Successfully saved!")
    })
}

function scrapeWeb(){
    getHTMLData(function(data){
        parseHTML(data)
    })
    
  
}

scrapeWeb()